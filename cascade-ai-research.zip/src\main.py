"""
main.py
-------
End-to-end reproduction of the experiments in
"AI-Based Cascade Failure Risk Prediction in Complex Networked Systems".

Pipeline
    1. Load the canonical dataset (../data) -- the same BA(100,3) realisation
       used by the dashboard (Table I: N=100, M=291, <d>=5.82, d_max=24).
    2. Train baselines + GCN + GAT and report the performance table (Table III).
    3. Per-class ROC-AUC / AUPRC for the GAT (Table V) + confusion matrix (Fig. 2).
    4. Ablation over feature subsets (Table VII).
    5. Sequential node-protection experiment (Table VIII).

Run:
    python src/main.py                 # full run (needs torch + torch_geometric)
    python src/main.py --no-gnn        # classical baselines only (no torch)
"""
import argparse
import os
import sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(__file__))
import dataset as ds
import models as M
import evaluate as E
from features import standardize, add_noise
from cascade_simulation import simulate_cascade

SEED = 42
np.random.seed(SEED)
DATA_DIR = ds.DATA_DIR


# --------------------------------------------------------------------------- #
#  Centrality baselines (percentile-thresholded ranking)
# --------------------------------------------------------------------------- #
def centrality_predict(values, train_idx):
    """Assign Low/Med/High by the 33rd/67th percentile of a single centrality,
    with thresholds fit on the training split (DC and BC baselines)."""
    p33, p67 = np.percentile(values[train_idx], [33, 67])
    y = np.ones(len(values), dtype=int)
    y[values <= p33] = 0
    y[values > p67] = 2
    return y


# --------------------------------------------------------------------------- #
#  Node-protection experiment (Table VIII)
# --------------------------------------------------------------------------- #
def mean_cascade_fraction(g, loads, capacity_mult, protected, alpha=0.20):
    """Mean cascade size / N after doubling capacity of `protected` nodes."""
    loads_eff = loads.copy()
    # protection = capacity doubled  <=>  effective load halved for the test
    # (we model it by scaling capacity via an effective alpha per node)
    n = g.number_of_nodes()
    sizes = []
    prot = set(protected)
    for s in range(n):
        sizes.append(_cascade_protected(g, s, loads, prot, alpha, capacity_mult))
    return np.mean(sizes) / n


def _cascade_protected(g, seed_node, loads, protected, alpha, mult):
    n = g.number_of_nodes()
    L = loads.astype(float).copy()
    C = (1.0 + alpha) * loads
    for p in protected:
        C[p] *= mult                       # hardened capacity
    deg = dict(g.degree())
    failed = np.zeros(n, dtype=bool)
    failed[seed_node] = True
    front = [seed_node]
    guard = 0
    while front and guard < n:
        guard += 1
        contrib = np.zeros(n)
        for i in front:
            d = deg[i] or 1
            for j in g.neighbors(i):
                if not failed[j]:
                    contrib[j] += L[i] / d
        nxt = []
        for j in range(n):
            if not failed[j] and contrib[j] > 0:
                L[j] += contrib[j]
                if L[j] > C[j]:
                    failed[j] = True
                    nxt.append(j)
        front = nxt
    return int(failed.sum())


# --------------------------------------------------------------------------- #
def main(use_gnn=True):
    print("=" * 64)
    print(" CASCADE AI — experiment reproduction")
    print("=" * 64)

    X, y, edge_index, splits = ds.load_numpy(DATA_DIR)
    g = ds.load_graph(DATA_DIR)
    train_idx, val_idx, test_idx = splits["train"], splits["val"], splits["test"]
    print(f" dataset: N={X.shape[0]}  M={g.number_of_edges()}  "
          f"classes={np.bincount(y).tolist()}  "
          f"train/val/test={len(train_idx)}/{len(val_idx)}/{len(test_idx)}\n")

    # standardised features (train-split statistics) + training-time noise
    Xs, _, _ = standardize(X, train_idx)
    rng = np.random.default_rng(SEED)
    Xtr = add_noise(Xs, rng=rng)

    results = {}

    # ---- Logistic Regression ----
    lr = M.make_logistic_regression().fit(Xtr[train_idx], y[train_idx])
    results["Logistic Regression"] = (E.classification_metrics(y[test_idx], lr.predict(Xs[test_idx])), None)

    # ---- Degree / Betweenness centrality ----
    results["Degree Centrality"] = (
        E.classification_metrics(y[test_idx], centrality_predict(X[:, 0], train_idx)[test_idx]), None)
    results["Betweenness Centrality"] = (
        E.classification_metrics(y[test_idx], centrality_predict(X[:, 2], train_idx)[test_idx]), None)

    # ---- MLP (no graph) ----
    mlp = M.make_mlp().fit(Xtr[train_idx], y[train_idx])
    results["Multi-Layer Perceptron"] = (E.classification_metrics(y[test_idx], mlp.predict(Xs[test_idx])), None)

    # ---- Random Forest ----
    rf = M.make_random_forest().fit(Xtr[train_idx], y[train_idx])
    rf_prob = rf.predict_proba(Xs)
    results["Random Forest"] = (E.classification_metrics(y[test_idx], rf.predict(Xs[test_idx])),
                                E.per_class_auc(y[test_idx], rf_prob[test_idx]))

    gat_prob = None
    if use_gnn:
        try:
            import torch
            torch.manual_seed(SEED)
            from train import train_gnn, predict_gnn
            data = ds.to_pyg(Xs, y, edge_index, splits)

            gcn = M.build_gcn()
            gcn, info = train_gnn(gcn, data)
            gcn_pred, gcn_prob = predict_gnn(gcn, data)
            print(f" GCN early-stopped at epoch {info['best_epoch']}")
            results["GCN"] = (E.classification_metrics(y[test_idx], gcn_pred[test_idx]),
                              E.per_class_auc(y[test_idx], gcn_prob[test_idx]))

            gat = M.build_gat()
            gat, info = train_gnn(gat, data)
            gat_pred, gat_prob = predict_gnn(gat, data)
            print(f" GAT early-stopped at epoch {info['best_epoch']}\n")
            results["GAT (Proposed)"] = (E.classification_metrics(y[test_idx], gat_pred[test_idx]),
                                         E.per_class_auc(y[test_idx], gat_prob[test_idx]))
        except ImportError:
            print(" [!] torch / torch_geometric not installed — skipping GCN/GAT.")
            print("     install with: pip install torch torch_geometric\n")
            use_gnn = False

    # ---- performance table ----
    print(f"{'Model':<24}{'Acc.':>7}{'Prec.':>8}{'Recall':>8}{'F1':>7}")
    print("-" * 54)
    order = ["Logistic Regression", "Degree Centrality", "Betweenness Centrality",
             "Multi-Layer Perceptron", "Random Forest", "GCN", "GAT (Proposed)"]
    for name in order:
        if name not in results:
            continue
        m, _ = results[name]
        print(f"{name:<24}{m['accuracy']*100:>6.1f}%{m['precision']:>8.2f}"
              f"{m['recall']:>8.2f}{m['f1']:>7.2f}")

    # ---- per-class AUC (GAT) + confusion matrix ----
    if gat_prob is not None:
        print("\nPer-class ROC-AUC / AUPRC (GAT):")
        auc = results["GAT (Proposed)"][1]
        for c in E.CLASS_NAMES + ["macro"]:
            print(f"  {c:<8} AUC={auc[c]['auc']:.3f}  AUPRC={auc[c]['auprc']:.3f}")
        from train import predict_gnn  # noqa
        print("\nConfusion matrix (rows=true Low/Med/High):")
        print(E.confusion(y[test_idx], gat_prob[test_idx].argmax(1)))

    # ---- ablation (RF as a torch-free stand-in; swap for GAT when available) ----
    print("\nAblation (feature subsets, Random Forest proxy):")
    subsets = {"d+c+b": [0, 1, 2], "d+c": [0, 1], "d+b": [0, 2],
               "c+b": [1, 2], "d": [0], "c": [1], "b": [2]}
    for tag, cols in subsets.items():
        clf = M.make_random_forest().fit(Xtr[train_idx][:, cols], y[train_idx])
        acc = E.classification_metrics(y[test_idx], clf.predict(Xs[test_idx][:, cols]))["accuracy"]
        print(f"  {tag:<8} acc={acc*100:5.1f}%")

    # ---- node protection (uses true load-capacity cascades) ----
    loads = pd.read_csv(os.path.join(DATA_DIR, "node_loads.csv"))["load"].to_numpy()
    print("\nSequential node protection (mean cascade size / N):")
    rank = np.argsort(-X[:, 0])           # rank by degree (proxy critical-node ranking)
    print(f"  {'k':>3}  {'S/N':>6}")
    for k in [0, 1, 3, 5, 10, 20]:
        frac = mean_cascade_fraction(g, loads, capacity_mult=2.0,
                                     protected=rank[:k].tolist())
        print(f"  {k:>3}  {frac:>6.2f}")

    print("\nDone. (See README.md for how the reported paper figures map to this run.)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-gnn", action="store_true", help="skip GCN/GAT (no torch needed)")
    args = ap.parse_args()
    main(use_gnn=not args.no_gnn)
