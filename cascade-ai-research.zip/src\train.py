"""
train.py
--------
Training routine for the GNNs (Section IV-D):

    optimiser   : Adam, lr = 1e-3, weight_decay = 5e-4
    objective   : L2-regularised categorical cross-entropy (Eq. 10)
    max_epochs  : 200
    early stop  : patience = 20 on validation loss, restore best checkpoint
"""
LR = 1e-3
WEIGHT_DECAY = 5e-4
MAX_EPOCHS = 200
PATIENCE = 20


def train_gnn(model, data, max_epochs=MAX_EPOCHS, patience=PATIENCE,
              lr=LR, weight_decay=WEIGHT_DECAY, verbose=False):
    import copy
    import torch
    import torch.nn.functional as F

    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    best_val, best_state, best_epoch, wait = float("inf"), None, 0, 0
    history = []

    for epoch in range(1, max_epochs + 1):
        model.train()
        opt.zero_grad()
        out = model(data.x, data.edge_index)
        loss = F.cross_entropy(out[data.train_mask], data.y[data.train_mask])
        loss.backward()
        opt.step()

        model.eval()
        with torch.no_grad():
            out = model(data.x, data.edge_index)
            val_loss = F.cross_entropy(out[data.val_mask], data.y[data.val_mask]).item()
        history.append((epoch, loss.item(), val_loss))
        if verbose and epoch % 10 == 0:
            print(f"  epoch {epoch:3d}  train {loss.item():.3f}  val {val_loss:.3f}")

        if val_loss < best_val - 1e-5:
            best_val, best_state, best_epoch, wait = val_loss, copy.deepcopy(model.state_dict()), epoch, 0
        else:
            wait += 1
            if wait >= patience:
                break

    if best_state is not None:
        model.load_state_dict(best_state)
    return model, {"best_epoch": best_epoch, "best_val_loss": best_val, "history": history}


def predict_gnn(model, data):
    """Return (pred_labels, class_probabilities) over all nodes."""
    import torch
    import torch.nn.functional as F
    model.eval()
    with torch.no_grad():
        logits = model(data.x, data.edge_index)
        prob = F.softmax(logits, dim=1).cpu().numpy()
    return prob.argmax(axis=1), prob
