"""
cascade_simulation.py
---------------------
Load-capacity cascade failure model (Algorithm 1, Section IV-A).

Each node i is assigned initial load L_i ~ U(0,1) and capacity
C_i = (1 + alpha) * L_i. A cascade seeded at v_s redistributes a failed
node's load equally to its surviving neighbours (Delta = L_i / d_i); a node
fails when its accumulated load exceeds its capacity. The cascade size S_s is
the number of failed nodes when propagation stops (terminates in <= N-1 steps,
Theorem V.1).

Node-level risk labels are produced by discretising the cascade-size
distribution at the 33rd and 67th percentiles into Low/Medium/High classes.
"""
import numpy as np
import networkx as nx

ALPHA_DEFAULT = 0.20


def simulate_cascade(g: nx.Graph, seed_node: int, loads: np.ndarray,
                     alpha: float = ALPHA_DEFAULT) -> int:
    """Run the deterministic load-capacity cascade from `seed_node`.

    Returns the cascade size S_s = |F_s| (number of failed nodes, incl. seed).
    """
    n = g.number_of_nodes()
    L = loads.astype(float).copy()
    C = (1.0 + alpha) * loads
    deg = dict(g.degree())
    failed = np.zeros(n, dtype=bool)
    failed[seed_node] = True
    front = [seed_node]

    guard = 0
    while front and guard < n:
        guard += 1
        contrib = np.zeros(n)
        for i in front:
            d = deg[i] or 1
            for j in g.neighbors(i):
                if not failed[j]:
                    contrib[j] += L[i] / d
        nxt = []
        for j in range(n):
            if not failed[j] and contrib[j] > 0:
                L[j] += contrib[j]
                if L[j] > C[j]:
                    failed[j] = True
                    nxt.append(j)
        front = nxt
    return int(failed.sum())


def cascade_sizes(g: nx.Graph, loads: np.ndarray,
                  alpha: float = ALPHA_DEFAULT) -> np.ndarray:
    """Cascade size for every node used in turn as the seed."""
    return np.array([simulate_cascade(g, s, loads, alpha)
                     for s in range(g.number_of_nodes())])


def risk_labels(sizes: np.ndarray) -> np.ndarray:
    """3-class labels from cascade-size percentiles (0=Low, 1=Medium, 2=High)."""
    p33, p67 = np.percentile(sizes, [33, 67])
    y = np.ones(len(sizes), dtype=int)        # Medium by default
    y[sizes <= p33] = 0                        # Low
    y[sizes > p67] = 2                         # High
    return y
