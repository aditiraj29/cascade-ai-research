"""
dataset.py
----------
Loads the canonical CSV dataset in ../data (generated to match the dashboard
and the paper's Table I) into NumPy arrays, a NetworkX graph, and a PyTorch
Geometric `Data` object.

Files:
    data/node_features.csv : node_id, degree, clustering, betweenness
    data/node_labels.csv   : node_id, cascade_size, risk_class, risk_label, split
    data/edges.csv         : source, target
"""
import os
import numpy as np
import pandas as pd
import networkx as nx

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")


def load_dataframes(data_dir: str = DATA_DIR):
    feats = pd.read_csv(os.path.join(data_dir, "node_features.csv"))
    labels = pd.read_csv(os.path.join(data_dir, "node_labels.csv"))
    edges = pd.read_csv(os.path.join(data_dir, "edges.csv"))
    df = feats.merge(labels, on="node_id").sort_values("node_id").reset_index(drop=True)
    return df, edges


def load_numpy(data_dir: str = DATA_DIR):
    """Return X (N,3), y (N,), edge_index (2,E), and split index arrays."""
    df, edges = load_dataframes(data_dir)
    X = df[["degree", "clustering", "betweenness"]].to_numpy(dtype=float)
    y = df["risk_class"].to_numpy(dtype=int)
    src = edges["source"].to_numpy()
    dst = edges["target"].to_numpy()
    # undirected: add both directions
    edge_index = np.vstack([np.concatenate([src, dst]),
                            np.concatenate([dst, src])])
    splits = {s: df.index[df["split"] == s].to_numpy() for s in ("train", "val", "test")}
    return X, y, edge_index, splits


def load_graph(data_dir: str = DATA_DIR) -> nx.Graph:
    df, edges = load_dataframes(data_dir)
    g = nx.Graph()
    g.add_nodes_from(df["node_id"].tolist())
    g.add_edges_from(edges[["source", "target"]].itertuples(index=False, name=None))
    return g


def to_pyg(X, y, edge_index, splits):
    """Build a torch_geometric Data object (imported lazily)."""
    import torch
    from torch_geometric.data import Data
    n = X.shape[0]
    data = Data(
        x=torch.tensor(X, dtype=torch.float),
        y=torch.tensor(y, dtype=torch.long),
        edge_index=torch.tensor(edge_index, dtype=torch.long),
    )
    for name, idx in splits.items():
        mask = torch.zeros(n, dtype=torch.bool)
        mask[idx] = True
        setattr(data, f"{name}_mask", mask)
    return data
