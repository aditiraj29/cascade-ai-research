"""
models.py
---------
Model definitions matching Table II (Hyperparameter Configuration):

    Random Forest : 300 trees, Gini, m_try = sqrt(F)
    GCN           : 2 layers, hidden 32, dropout 0.5
    GAT           : 2 layers, hidden 16, 4 attention heads, dropout 0.5
    MLP           : same hidden dims as GCN, no graph structure (topology ablation)

GNNs (GCN/GAT) require torch + torch_geometric; they are imported lazily so the
classical baselines still run in a torch-free environment.
"""
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier

RANDOM_STATE = 42


# ----------------------------- classical -----------------------------------
def make_random_forest():
    return RandomForestClassifier(
        n_estimators=300, criterion="gini", max_features="sqrt",
        random_state=RANDOM_STATE, n_jobs=-1,
    )


def make_logistic_regression():
    return LogisticRegression(max_iter=1000, multi_class="multinomial",
                              random_state=RANDOM_STATE)


def make_mlp():
    # graph-free baseline: isolates the contribution of topology
    return MLPClassifier(hidden_layer_sizes=(32,), max_iter=500,
                         alpha=5e-4, random_state=RANDOM_STATE)


# ------------------------------- GNNs --------------------------------------
def build_gcn(in_dim=3, hidden=32, out_dim=3, dropout=0.5):
    import torch.nn as nn
    import torch.nn.functional as F
    from torch_geometric.nn import GCNConv

    class GCN(nn.Module):
        def __init__(self):
            super().__init__()
            self.c1 = GCNConv(in_dim, hidden)
            self.c2 = GCNConv(hidden, out_dim)
            self.dropout = dropout

        def forward(self, x, edge_index):
            x = F.relu(self.c1(x, edge_index))
            x = F.dropout(x, p=self.dropout, training=self.training)
            x = self.c2(x, edge_index)
            return x
    return GCN()


def build_gat(in_dim=3, hidden=16, out_dim=3, heads=4, dropout=0.5):
    import torch.nn as nn
    import torch.nn.functional as F
    from torch_geometric.nn import GATConv

    class GAT(nn.Module):
        def __init__(self):
            super().__init__()
            # layer 1: `heads` heads concatenated -> hidden*heads features
            self.g1 = GATConv(in_dim, hidden, heads=heads, dropout=dropout)
            # layer 2: average heads -> out_dim logits
            self.g2 = GATConv(hidden * heads, out_dim, heads=heads,
                              concat=False, dropout=dropout)
            self.dropout = dropout

        def forward(self, x, edge_index):
            x = F.dropout(x, p=self.dropout, training=self.training)
            x = F.elu(self.g1(x, edge_index))
            x = F.dropout(x, p=self.dropout, training=self.training)
            x = self.g2(x, edge_index)
            return x
    return GAT()
