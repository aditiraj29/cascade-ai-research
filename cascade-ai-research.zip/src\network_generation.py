"""
network_generation.py
---------------------
Barabasi-Albert (scale-free) and Erdos-Renyi (random) network generation,
matching Section IV-A / Table I of the paper:

    BA:  N = 100, m = 3   ->  M = 291,  <d> = 5.82,  d_max = 24
    ER:  N = 100, p = 0.059 (~ 2m/(N-1))  ->  M ~ 290

The canonical dataset shipped in ../data was generated with the project's
seeded JS generator (mulberry32, seed=324) so that the CSVs match the live
dashboard exactly. This module lets you regenerate equivalent networks with
NetworkX for experimentation.
"""
import networkx as nx

N_DEFAULT = 100
M_DEFAULT = 3
P_ER_DEFAULT = 0.059
SEED = 42


def make_ba(n: int = N_DEFAULT, m: int = M_DEFAULT, seed: int = SEED) -> nx.Graph:
    """Barabasi-Albert scale-free graph: m*(n-m) edges (291 for n=100, m=3)."""
    return nx.barabasi_albert_graph(n, m, seed=seed)


def make_er(n: int = N_DEFAULT, p: float = P_ER_DEFAULT, seed: int = SEED) -> nx.Graph:
    """Erdos-Renyi G(n, p) random graph for structural comparison."""
    return nx.gnp_random_graph(n, p, seed=seed)


def network_stats(g: nx.Graph) -> dict:
    degs = [d for _, d in g.degree()]
    return {
        "nodes": g.number_of_nodes(),
        "edges": g.number_of_edges(),
        "mean_degree": round(sum(degs) / len(degs), 2),
        "max_degree": max(degs),
        "mean_clustering": round(nx.average_clustering(g), 3),
    }


if __name__ == "__main__":
    print("BA:", network_stats(make_ba()))
    print("ER:", network_stats(make_er()))
