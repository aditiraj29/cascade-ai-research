"""
features.py
-----------
Structural feature extraction (Section III-C):

    d_i  : degree
    c_i  : local clustering coefficient
    b_i  : betweenness centrality (normalised)

Features are z-score standardised using statistics computed on the TRAINING
split only (to prevent leakage); Gaussian noise (sigma=0.01) is injected during
training as a regulariser (Proposition V.23).
"""
import numpy as np
import networkx as nx

NOISE_STD = 0.01


def extract_features(g: nx.Graph) -> np.ndarray:
    """Return an (N, 3) matrix of [degree, clustering, betweenness]."""
    n = g.number_of_nodes()
    deg = dict(g.degree())
    clus = nx.clustering(g)
    btw = nx.betweenness_centrality(g, normalized=True)
    X = np.zeros((n, 3))
    for i in range(n):
        X[i] = [deg[i], clus[i], btw[i]]
    return X


def standardize(X: np.ndarray, train_idx: np.ndarray, eps: float = 1e-8):
    """Z-score standardisation using train-split statistics only."""
    mu = X[train_idx].mean(axis=0)
    sigma = X[train_idx].std(axis=0)
    Xs = (X - mu) / (sigma + eps)
    return Xs, mu, sigma


def add_noise(X: np.ndarray, std: float = NOISE_STD, rng=None) -> np.ndarray:
    """Inject zero-mean Gaussian noise (training-time regularisation)."""
    rng = rng or np.random.default_rng(0)
    return X + rng.normal(0.0, std, size=X.shape)
