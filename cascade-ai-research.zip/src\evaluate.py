"""
evaluate.py
-----------
Evaluation metrics (Section VI): macro accuracy / precision / recall / F1,
per-class one-vs-rest ROC-AUC and AUPRC, and the confusion matrix.
"""
import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, confusion_matrix,
)

CLASSES = [0, 1, 2]
CLASS_NAMES = ["Low", "Medium", "High"]


def classification_metrics(y_true, y_pred) -> dict:
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "recall": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "f1": f1_score(y_true, y_pred, average="macro", zero_division=0),
    }


def per_class_auc(y_true, y_prob) -> dict:
    """One-vs-rest AUC and AUPRC per class plus macro averages."""
    y_true = np.asarray(y_true)
    out = {}
    aucs, auprcs = [], []
    for c in CLASSES:
        binary = (y_true == c).astype(int)
        if binary.sum() == 0 or binary.sum() == len(binary):
            auc = aup = float("nan")
        else:
            auc = roc_auc_score(binary, y_prob[:, c])
            aup = average_precision_score(binary, y_prob[:, c])
        out[CLASS_NAMES[c]] = {"auc": auc, "auprc": aup}
        aucs.append(auc); auprcs.append(aup)
    out["macro"] = {"auc": float(np.nanmean(aucs)), "auprc": float(np.nanmean(auprcs))}
    return out


def confusion(y_true, y_pred):
    return confusion_matrix(y_true, y_pred, labels=CLASSES)
